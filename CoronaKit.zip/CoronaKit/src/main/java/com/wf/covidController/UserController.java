package com.wf.covidController;

import java.io.IOException;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import javax.servlet.RequestDispatcher;

import com.wf.dao.KitDao;
import com.wf.dao.ProductMasterDao;
import com.wf.model.CoronaKit;
import com.wf.model.KitDetail;
import com.wf.model.OrderSummary;
import com.wf.model.ProductMaster;
/**
 * Servlet implementation class covController
 */
@WebServlet("/user")
public class UserController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private String pname = "";
	private String pemail = "";
	private String pcontact = "";
	private String paddress = "";
	
	
	
	  private KitDao kitDAO; 
	  private ProductMasterDao productMasterDao;
	  
	  public void setKitDAO(KitDao kitDAO) { 
		  this.kitDAO = kitDAO; 
		  }
	  
	  public void setProductMasterDao(ProductMasterDao productMasterDao) {
		  this.productMasterDao = productMasterDao; 
	  }
	 
	
	public void init(ServletConfig config) {
		String jdbcURL = config.getServletContext().getInitParameter("jdbcUrl");
		String jdbcUsername = config.getServletContext().getInitParameter("jdbcUsername");
		String jdbcPassword = config. getServletContext().getInitParameter("jdbcPassword");
		
		
		  this.kitDAO = new KitDao(jdbcURL, jdbcUsername, jdbcPassword);
		  this.productMasterDao = new ProductMasterDao(jdbcURL, jdbcUsername,
		  jdbcPassword);
		 
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String action = request.getParameter("action");
		
		String viewName = "";
		try {
			switch (action) {
			case "newuser":
				viewName = showNewUserForm(request, response);//done
				break;
			case "insertuser":
				viewName = insertNewUser(request, response);//done
				break;
			case "addnewitem":
				viewName = addNewItemToKit(request, response);
				break;
			case "deleteitem":
				viewName = deleteItemFromKit(request, response);
				break;
			case "showkit":
				viewName = showKitDetails(request, response);
				break;
			case "showproducts":
				//used to go back from kit details screen to previous screen
				viewName = showAllProducts(request, response);
				break;
			case "placeorder":
				viewName = showPlaceOrderForm(request, response);
				break;
			case "saveorder":
				viewName = saveOrderForDelivery(request, response);
				break;	
			/*
			 * case "ordersummary": viewName = showOrderSummary(request, response); break;
			 */	
			default : viewName = "notfound.jsp"; break;	
			}
		} catch (Exception ex) {
			
			throw new ServletException(ex.getMessage());
		}
			RequestDispatcher dispatch = 
					request.getRequestDispatcher(viewName);
			dispatch.forward(request, response);
	
	}

	private String showAllProducts(HttpServletRequest request, HttpServletResponse response) throws ClassNotFoundException, SQLException {
		try {
				
		List<ProductMaster> products = this.productMasterDao.getProductRecords();
				// put data into request object (to share with view page)
				request.setAttribute("products", products);
				return "showproductstoadd.jsp";
			
		} catch (ClassNotFoundException e) {
			// TODO: handle exception
			throw new ClassNotFoundException(e.getMessage());
		} catch (SQLException e) {
			// TODO: handle exception
			throw new SQLException(e.getMessage());
		}
	}

	/*
	 * private String showOrderSummary(HttpServletRequest request,
	 * HttpServletResponse response) { // TODO Auto-generated method stub return "";
	 * }
	 */

	private String saveOrderForDelivery(HttpServletRequest request, HttpServletResponse response) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		try {
			this.pname = request.getParameter("pname");
			this.pemail = request.getParameter("pemail");
			this.pcontact = request.getParameter("pcontact");
			this.paddress = request.getParameter("paddress");
		    OrderSummary order = this.kitDAO.saveOrder(pname, pemail, pcontact, paddress);
				
			request.setAttribute("orderSummary", order);
LinkedHashMap<Integer, String> prodName = new LinkedHashMap<Integer, String>();
LinkedHashMap<Integer, String> prodDetail = new LinkedHashMap<Integer, String>();	
			for(KitDetail kit : order.getKitDetails()){	
					
				//still this way setting few key's value as null :(	
				prodName.put(kit.getProductId(), kitDAO.getProdName(kit.getProductId()));
				prodDetail.put(kit.getProductId(), kitDAO.getProdDetail(kit.getProductId()));	
							
				}
			request.setAttribute("prodNames", prodName);
			request.setAttribute("prodDetails", prodDetail);
				return "ordersummary.jsp";
			
		} catch (ClassNotFoundException e) {
			// TODO: handle exception
			throw new ClassNotFoundException(e.getMessage());
		} catch (SQLException e) {
			// TODO: handle exception
			throw new SQLException(e.getMessage());
		}
		
	}

	private String showPlaceOrderForm(HttpServletRequest request, HttpServletResponse response) {
		// TODO Auto-generated method stub
		
		  request.setAttribute("pname", pname); 
		  request.setAttribute("pemail", pemail);
		  request.setAttribute("pcontact", pcontact); 
		 
		return "placeorder.jsp";
	}

	private String showKitDetails(HttpServletRequest request, HttpServletResponse response) throws ClassNotFoundException, SQLException, ServletException {
		try {
			List<KitDetail> kits = this.kitDAO.getKitRecords();
				request.setAttribute("kits", kits);
			
			LinkedHashMap<Integer, String> prodName = new LinkedHashMap<Integer, String>();
			
			for(KitDetail kit : kits){	
					
				//still this way setting few key's value as null :(	
				prodName.put(kit.getProductId(), kitDAO.getProdName(kit.getProductId()));
					
							
				}
			request.setAttribute("prodNames", prodName);
				return "showkit.jsp";
			
		} catch (SQLException e) {
			// TODO: handle exception
			throw new SQLException(e.getMessage());
		}catch (Exception ex) {
			System.out.println("error");
			throw new ServletException(ex.getMessage());
		}
	}

	private String deleteItemFromKit(HttpServletRequest request, HttpServletResponse response) throws ClassNotFoundException, SQLException {
		try {
			int id = Integer.parseInt(request.getParameter("id"));
			this.kitDAO.deleteProduct(id);
			
		List<ProductMaster> products = this.productMasterDao.getProductRecords();
		request.setAttribute("products", products);
		return "showproductstoadd.jsp";
		} catch (ClassNotFoundException e) {
			// TODO: handle exception
			throw new ClassNotFoundException(e.getMessage());
		} catch (SQLException e) {
			// TODO: handle exception
			throw new SQLException(e.getMessage());
		}
	}

	private String addNewItemToKit(HttpServletRequest request, HttpServletResponse response) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		try {
			int id = Integer.parseInt(request.getParameter("id"));
			this.kitDAO.addProduct(id);
			
		List<ProductMaster> products = this.productMasterDao.getProductRecords();
		request.setAttribute("products", products);
		return "showproductstoadd.jsp";
		} catch (ClassNotFoundException e) {
			// TODO: handle exception
			throw new ClassNotFoundException(e.getMessage());
		} catch (SQLException e) {
			// TODO: handle exception
			throw new SQLException(e.getMessage());
		}
	}

	

	private String insertNewUser(HttpServletRequest request, HttpServletResponse response) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		try {
			this.pname = request.getParameter("pname");
			this.pemail = request.getParameter("pemail");
			this.pcontact = request.getParameter("pcontact");	
		List<ProductMaster> products = this.productMasterDao.getProductRecords();
				// put data into request object (to share with view page)
				request.setAttribute("products", products);
				return "showproductstoadd.jsp";
			
		} catch (ClassNotFoundException e) {
			// TODO: handle exception
			throw new ClassNotFoundException(e.getMessage());
		} catch (SQLException e) {
			// TODO: handle exception
			throw new SQLException(e.getMessage());
		}
		
	}

	private String showNewUserForm(HttpServletRequest request, HttpServletResponse response) {
		// TODO Auto-generated method stub
		return "newuser.jsp";
	}

}
