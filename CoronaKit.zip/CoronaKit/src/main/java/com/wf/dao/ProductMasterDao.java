package com.wf.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;


import com.wf.model.ProductMaster;

public class ProductMasterDao {
	private String jdbcDriver = "com.mysql.jdbc.Driver";
	private String jdbcURL;
	private String jdbcUsername;
	private String jdbcPassword;
	private Connection jdbcConnection;

	public ProductMasterDao(String jdbcURL, String jdbcUsername, String jdbcPassword) {
        this.jdbcURL = jdbcURL;
        this.jdbcUsername = jdbcUsername;
        this.jdbcPassword = jdbcPassword;
    }

	protected void connect() throws SQLException {
		if (jdbcConnection == null || jdbcConnection.isClosed()) {
			try {
				Class.forName(jdbcDriver);
			} catch (ClassNotFoundException e) {
				throw new SQLException(e);
			}
			jdbcConnection = DriverManager.getConnection(jdbcURL, jdbcUsername, jdbcPassword);
		}
	}

	protected void disconnect() throws SQLException {
		if (jdbcConnection != null && !jdbcConnection.isClosed()) {
			jdbcConnection.close();
		}
	}
	
	public List<ProductMaster> getProductRecords() throws ClassNotFoundException, SQLException{
		// TODO Auto-generated method stub
		String sql = "select * from Product";
		this.connect();
		Statement stmt = this.jdbcConnection.createStatement();
		ResultSet rs = stmt.executeQuery(sql);
		
		List<ProductMaster> products = new ArrayList<ProductMaster>();
		while(rs.next()) {
			ProductMaster product = new ProductMaster(rs.getInt("id"), 
											 rs.getString("name"), 
											 rs.getInt("cost"), 
											 rs.getString("description"));
			products.add(product);		
		}
		
		rs.close();
		stmt.close();
		this.disconnect();
		
		return products;
		
	}

	public void updateProduct(int id, String name, int cost, String detail) throws SQLException,ClassNotFoundException {
		// TODO Auto-generated method stub
		String sql = "update product set " + "name = ?," + "cost = ?," + "description = ?" + "where id = ?";
		this.connect(); 
		PreparedStatement pstmt = this.jdbcConnection.prepareStatement(sql);
		pstmt.setString(1, name);
		pstmt.setDouble(2, cost);
		pstmt.setString(3, detail);
		pstmt.setInt(4, id);
		int row = pstmt.executeUpdate();
		pstmt.close();
		this.disconnect();
	}

	public void deleteProduct(int id) throws SQLException,ClassNotFoundException {
		// TODO Auto-generated method stub
		String sql = "delete from product " + "where id = ?";
		this.connect(); 
		PreparedStatement pstmt = this.jdbcConnection.prepareStatement(sql);
		pstmt.setInt(1, id);
		int row = pstmt.executeUpdate();
		pstmt.close();
		this.disconnect();
	}

	public void addProduct(String name, int cost, String detail) throws SQLException,ClassNotFoundException {
		String sql = "insert into product(name,cost,description)"+ "values(?,?,?)";
		this.connect(); 
		PreparedStatement pstmt = this.jdbcConnection.prepareStatement(sql);
		//id will be auto-increment in database
		pstmt.setString(1, name);
		pstmt.setInt(2, cost);
		pstmt.setString(3, detail);
		pstmt.execute();
		pstmt.close();
		this.disconnect();
		
	}

	public ProductMaster getProductDetail(int id) throws SQLException,ClassNotFoundException {
		// TODO Auto-generated method stub
		ProductMaster product = null;
		String sql = "select * from Product where id =?";
		this.connect();
		PreparedStatement pstmt = this.jdbcConnection.prepareStatement(sql);
		pstmt.setInt(1, id);
		ResultSet rs = pstmt.executeQuery();
		while(rs.next()) {
		product = new ProductMaster(rs.getInt("id"), 
				 rs.getString("name"), 
				 rs.getInt("cost"), 
				 rs.getString("description"));
		}
		pstmt.close();
		this.disconnect();
		return product;
	}
}
