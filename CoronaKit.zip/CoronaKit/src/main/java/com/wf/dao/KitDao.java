package com.wf.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.wf.model.CoronaKit;
import com.wf.model.KitDetail;
import com.wf.model.OrderSummary;
import com.wf.model.ProductMaster;



public class KitDao {

	private String jdbcURL;
	private String jdbcUsername;
	private String jdbcPassword;
	private Connection jdbcConnection;

	public KitDao(String jdbcURL, String jdbcUsername, String jdbcPassword) {
        this.jdbcURL = jdbcURL;
        this.jdbcUsername = jdbcUsername;
        this.jdbcPassword = jdbcPassword;
    }

	protected void connect() throws SQLException {
		if (jdbcConnection == null || jdbcConnection.isClosed()) {
			try {
				Class.forName("com.mysql.jdbc.Driver");
			} catch (ClassNotFoundException e) {
				throw new SQLException(e);
			}
			jdbcConnection = DriverManager.getConnection(jdbcURL, jdbcUsername, jdbcPassword);
		}
	}

	protected void disconnect() throws SQLException {
		if (jdbcConnection != null && !jdbcConnection.isClosed()) {
			jdbcConnection.close();
		}
	}

	public void addProduct(int id) throws SQLException,ClassNotFoundException{
		// TODO Auto-generated method stub
		try {
			String sql = "select * from kit where prod_id = ? and ck_id is null";
			this.connect();
			PreparedStatement pstmt = this.jdbcConnection.prepareStatement(sql);
			pstmt.setInt(1, id);
			ResultSet rs = pstmt.executeQuery();
			KitDetail kitRecord = null;
			while(rs.next()) {
				kitRecord = new KitDetail(rs.getInt("kit_id"),
					 rs.getInt("ck_id"),
					 rs.getInt("prod_id"), 
					 rs.getInt("kit_quantity"), 
					 rs.getInt("kit_amt"));
			}
			pstmt.close();
			String sql2 = "select * from product where id = ?";
			PreparedStatement pstmt2 = this.jdbcConnection.prepareStatement(sql2);
			pstmt2.setInt(1, id);
			ResultSet rs2 = pstmt2.executeQuery();
			ProductMaster product = null;
			while(rs2.next()) {
			product = new ProductMaster(rs2.getInt("id"), 
					 rs2.getString("name"), 
					 rs2.getInt("cost"), 
					 rs2.getString("description"));
			}
			
			if (kitRecord==null) {
				String sql1 = "insert into kit(prod_id, kit_quantity, kit_amt) " +"values(?,?,?)";
				PreparedStatement pstmt1 = this.jdbcConnection.prepareStatement(sql1);
				pstmt1.setInt(1, id);
				pstmt1.setInt(2, 1);
				pstmt1.setInt(3, product.getCost());
				pstmt1.execute();
				pstmt1.close();
				
			} else {
				
				String sql3 = "update kit set"+" kit_quantity = ?,"+" kit_amt = ?"+" where kit_id =?";
				PreparedStatement pstmt3 = this.jdbcConnection.prepareStatement(sql3);
				int a= kitRecord.getQuantity()+1;
				pstmt3.setInt(1, a);
				int b = kitRecord.getAmount()+product.getCost();
				pstmt3.setInt(2, b);
				pstmt3.setInt(3, kitRecord.getId());
				int row = pstmt3.executeUpdate();
				pstmt3.close();
				
			}
			
			this.disconnect();	
		}catch (SQLException e) {
			// TODO: handle exception
			throw new SQLException(e.getMessage());
		}
	}

	public void deleteProduct(int id) throws SQLException {
		try {
			String sql = "select * from kit where prod_id = ? and ck_id is null";
			this.connect();
			PreparedStatement pstmt = this.jdbcConnection.prepareStatement(sql);
			pstmt.setInt(1, id);
			ResultSet rs = pstmt.executeQuery();
			KitDetail kitRecord = null;
			while(rs.next()) {
				kitRecord = new KitDetail(rs.getInt("kit_id"),
					 rs.getInt("ck_id"),
					 rs.getInt("prod_id"), 
					 rs.getInt("kit_quantity"), 
					 rs.getInt("kit_amt"));
			}
			pstmt.close();
			String sql2 = "select * from product where id = ?";
			PreparedStatement pstmt2 = this.jdbcConnection.prepareStatement(sql2);
			pstmt2.setInt(1, id);
			ResultSet rs2 = pstmt2.executeQuery();
			ProductMaster product = null;
			while(rs2.next()) {
			product = new ProductMaster(rs2.getInt("id"), 
					 rs2.getString("name"), 
					 rs2.getInt("cost"), 
					 rs2.getString("description"));
			}
			
			if(kitRecord.getQuantity()==1) {
				String sql1 = "delete from kit where prod_id = ? and ck_id is null";
				PreparedStatement pstmt1 = this.jdbcConnection.prepareStatement(sql1);
				pstmt1.setInt(1, id);
				pstmt1.execute();
				pstmt1.close();
				
			} else if(kitRecord.getQuantity()>1){
				
				String sql3 = "update kit set"+" kit_quantity = ?,"+" kit_amt = ?"+" where kit_id =?";
				PreparedStatement pstmt3 = this.jdbcConnection.prepareStatement(sql3);
				int a= kitRecord.getQuantity()-1;
				pstmt3.setInt(1, a);
				int b = kitRecord.getAmount()-product.getCost();
				pstmt3.setInt(2, b);
				pstmt3.setInt(3, kitRecord.getId());
				int row = pstmt3.executeUpdate();
				pstmt3.close();
				
			}
			
			this.disconnect();	
		}catch (SQLException e) {
			// TODO: handle exception
			throw new SQLException(e.getMessage());
		}
		
	}

	public List<KitDetail> getKitRecords() throws SQLException {
		String sql = "select * from kit where ck_id is null";
		this.connect();
		Statement stmt = this.jdbcConnection.createStatement();
		ResultSet rs = stmt.executeQuery(sql);
		List<HashMap<Integer,String>> prodNames = new ArrayList<HashMap<Integer,String>>();
		HashMap<Integer, String> prodName = new HashMap<Integer, String>();
		List<KitDetail> kits = new ArrayList<KitDetail>();
		while(rs.next()) {
			KitDetail kit = new KitDetail(rs.getInt("kit_id"), 
											 rs.getInt("ck_id"), 
											 rs.getInt("prod_id"), 
											 rs.getInt("kit_quantity"),
											 rs.getInt("kit_amt"));
			prodName.put(rs.getInt("prod_id"), "");
			prodNames.add(prodName);
			kits.add(kit);		
		}
		
		rs.close();
		stmt.close();
		this.disconnect();
		
		return kits;
	}

	public String getProdName(int id) throws SQLException {
		// TODO Auto-generated method stub
		String prodName=null;
		String sql = "select * from Product where id =?";
		this.connect();
		PreparedStatement pstmt = this.jdbcConnection.prepareStatement(sql);
		pstmt.setInt(1, id);
		ResultSet rs = pstmt.executeQuery();
		while(rs.next()) {
			prodName = rs.getString("name");
		}
		pstmt.close();
		this.disconnect();
		return prodName;
	}

	
	public OrderSummary saveOrder(String pname, String pemail, String pcontact, String paddress) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		OrderSummary orderDetail=null;
		CoronaKit coronaKit = null;
		List<KitDetail> kitDetails = new ArrayList<KitDetail>();
		int amount =0;
		String sql1 = "select kit_amt from kit where ck_id is null";
		this.connect();
		Statement stmt1 = this.jdbcConnection.createStatement();
		ResultSet rs1 = stmt1.executeQuery(sql1);
		while(rs1.next()) {
			amount = amount + rs1.getInt("kit_amt");
		}
		stmt1.close();
		
		String sql2 = "insert into covidkit(ck_pname,ck_email, ck_contact, ck_amount, ck_address, ck_date, ck_status)"+ "values(?,?,?,?,?,?,?)";
		 
		PreparedStatement pstmt2 = this.jdbcConnection.prepareStatement(sql2);
		//id will be auto-increment in database
		pstmt2.setString(1, pname);
		pstmt2.setString(2, pemail);
		pstmt2.setString(3, pcontact);
		pstmt2.setInt(4, amount);
		pstmt2.setString(5, paddress);
		pstmt2.setString(6, LocalDateTime.now().toString());
		pstmt2.setBoolean(7, true);
		pstmt2.execute();
		pstmt2.close();
		
		String sql3 = "select * from covidkit where ck_id = (select max(ck_id) from covidkit)";
		Statement stmt3 = this.jdbcConnection.createStatement();
		ResultSet rs3 = stmt3.executeQuery(sql3);
		while(rs3.next()) {
			coronaKit = new CoronaKit(rs3.getInt("ck_id"),
					 					rs3.getString("ck_pname"),
					 					rs3.getString("ck_email"),
					 					rs3.getString("ck_contact"),
					 					rs3.getInt("ck_amount"),
					 					rs3.getString("ck_address"),
					 					rs3.getString("ck_date"),
					 					rs3.getBoolean("ck_status"));
		}
		
		String sql4 = "update kit set"+" ck_id = ?"+" where ck_id is null";
		PreparedStatement pstmt4 = this.jdbcConnection.prepareStatement(sql4);
		pstmt4.setInt(1, coronaKit.getId());
		int row = pstmt4.executeUpdate();
		System.out.println("No of items ordered :" + row);
		pstmt4.close();
		
		String sql5 = "select * from kit where ck_id = ?";
		PreparedStatement pstmt5 = this.jdbcConnection.prepareStatement(sql5);
		pstmt5.setInt(1, coronaKit.getId());
		ResultSet rs5 = pstmt5.executeQuery();
		while(rs5.next()) {
			KitDetail kit = new KitDetail(rs5.getInt("kit_id"), 
					 rs5.getInt("ck_id"), 
					 rs5.getInt("prod_id"), 
					 rs5.getInt("kit_quantity"),
					 rs5.getInt("kit_amt"));
			kitDetails.add(kit);
		}
		pstmt5.close();
		
		orderDetail = new OrderSummary(coronaKit, kitDetails);
		
		this.disconnect();
		
		return orderDetail;
	}

	public String getProdDetail(int productId) throws SQLException  {
		String prodDetail=null;
		String sql = "select * from Product where id =?";
		this.connect();
		PreparedStatement pstmt = this.jdbcConnection.prepareStatement(sql);
		pstmt.setInt(1, productId);
		ResultSet rs = pstmt.executeQuery();
		while(rs.next()) {
			prodDetail = rs.getString("description");
		}
		pstmt.close();
		this.disconnect();
		return prodDetail;
	}

	

	// add DAO methods as per requirements
}